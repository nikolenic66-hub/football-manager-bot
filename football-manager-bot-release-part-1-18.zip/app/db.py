from pathlib import Path
import logging

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import text

from .config import settings

logger = logging.getLogger(__name__)

engine = create_async_engine(
    settings.database_url,
    pool_pre_ping=True,
    pool_recycle=1800,
    pool_size=2,
    max_overflow=0,
)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


def _split_sql_statements(sql: str) -> list[str]:
    """Split PostgreSQL SQL without breaking quoted strings or dollar blocks.

    Migrations may contain ordinary semicolon-separated statements as well as
    PL/pgSQL blocks such as DO $$ ... END $$;. SQLAlchemy's asyncpg prepared
    execution path accepts one statement at a time, so keep the splitter here
    instead of relying on driver-specific multi-statement behavior.
    """
    statements: list[str] = []
    buf: list[str] = []
    i = 0
    n = len(sql)
    quote: str | None = None
    dollar_tag: str | None = None
    line_comment = False
    block_comment = False

    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ''

        if line_comment:
            buf.append(ch)
            if ch == '\n':
                line_comment = False
            i += 1
            continue

        if block_comment:
            buf.append(ch)
            if ch == '*' and nxt == '/':
                buf.append(nxt)
                i += 2
                block_comment = False
                continue
            i += 1
            continue

        if dollar_tag is not None:
            if sql.startswith(dollar_tag, i):
                buf.append(dollar_tag)
                i += len(dollar_tag)
                dollar_tag = None
            else:
                buf.append(ch)
                i += 1
            continue

        if quote is not None:
            buf.append(ch)
            if ch == quote:
                if nxt == quote:
                    buf.append(nxt)
                    i += 2
                    continue
                quote = None
            elif ch == '\\' and quote == "'" and i + 1 < n:
                buf.append(nxt)
                i += 2
                continue
            i += 1
            continue

        if ch == '-' and nxt == '-':
            buf.extend((ch, nxt))
            i += 2
            line_comment = True
            continue
        if ch == '/' and nxt == '*':
            buf.extend((ch, nxt))
            i += 2
            block_comment = True
            continue
        if ch in ("'", '"'):
            quote = ch
            buf.append(ch)
            i += 1
            continue
        if ch == '$':
            j = i + 1
            while j < n and (sql[j].isalnum() or sql[j] == '_'):
                j += 1
            if j < n and sql[j] == '$':
                dollar_tag = sql[i:j + 1]
                buf.append(dollar_tag)
                i = j + 1
                continue
        if ch == ';':
            statement = ''.join(buf).strip()
            if statement:
                statements.append(statement)
            buf.clear()
            i += 1
            continue

        buf.append(ch)
        i += 1

    statement = ''.join(buf).strip()
    if statement:
        statements.append(statement)
    return statements


async def init_db():
    """Apply versioned SQL migrations once.

    Existing installations created by the old bootstrap runner are detected
    through the presence of the users table and marked as migrated without
    re-running historical/destructive SQL. Fresh databases run all migrations
    exactly once.
    """
    root = Path(__file__).resolve().parent.parent
    migrations = sorted((root / 'migrations').glob('*.sql'))
    async with engine.begin() as conn:
        await conn.execute(text("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                filename TEXT NOT NULL,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
            )
        """))
        existing_tables = (await conn.execute(text("""SELECT table_name FROM information_schema.tables
            WHERE table_schema='public' AND table_name = ANY(:names)"""),
            {'names':['users','players','clubs','leagues','matches','schema_migrations']})).scalars().all()
        existing = 'users' in existing_tables
        applied = set((await conn.execute(text('SELECT version FROM schema_migrations'))).scalars().all())
        if existing and not applied:
            # Legacy bootstrap databases did not record migration versions. Only
            # treat a clearly complete legacy schema as migrated; a partial schema
            # must fail visibly instead of silently skipping 001..011.
            legacy_core = {'users','players','clubs','leagues','matches'}
            if legacy_core.issubset(set(existing_tables)):
                logger.warning('Legacy bootstrap schema detected without schema_migrations; marking 001..011 as applied.')
                for migration in migrations:
                    version = int(migration.stem.split('_', 1)[0])
                    if version <= 11:
                        await conn.execute(
                            text('INSERT INTO schema_migrations(version,filename) VALUES(:v,:f)'),
                            {'v': version, 'f': migration.name},
                        )
                applied = {int(m.stem.split('_', 1)[0]) for m in migrations if int(m.stem.split('_', 1)[0]) <= 11}
            else:
                raise RuntimeError('schema_migrations is empty but the legacy schema is incomplete; refusing to guess migration state.')
        for migration in migrations:
            version = int(migration.stem.split('_', 1)[0])
            if version in applied:
                continue
            sql = migration.read_text(encoding='utf-8')
            for statement in _split_sql_statements(sql):
                result = await conn.execute(text(statement))
                if migration.name == '022_club_player_templates.sql' and statement.lstrip().upper().startswith('DELETE FROM CLUB_PLAYERS'):
                    logger.info('Migration 022 duplicate cleanup removed %s club_players rows.', result.rowcount)
            await conn.execute(
                text('INSERT INTO schema_migrations(version,filename) VALUES(:v,:f)'),
                {'v': version, 'f': migration.name},
            )
